# FFA Arena Lite

Fast, lightweight Free-For-All for Mage Arena. Jump in, fight everyone, last player standing wins.

## What you get
* **Free-For-All rules** – Everyone vs everyone. Last player standing wins the round.
* **Safe spawns** – The mod fills the game's spawn list so you don't spawn into null spots or on top of each other.
* **Local end screen** – When the round ends, everyone sees a winner message locally. No extra networking needed.
* **Minimal & compatible** – Small patch set designed to play nice with other mods.

## How to play
1. Host or join a game as usual.
2. Pick the FFA option in the lobby (if present) or just start a match – the mod prepares FFA automatically.
3. Fight until only one player remains.
4. The winner is shown, then you can start the next round.

## Features
* **Clean match flow** – Lobby → Fight → Winner overlay.
* **Spawn hydration** – Ensures `PlayerMovement.teamSpawns` is valid and sized to avoid vanilla crashes.
* **Only built‑in networking** – Uses the game's own death/respawn events; no custom network objects.

## Requirements
* BepInEx 5 (BepInExPack)
* HarmonyX

These are listed as dependencies on Thunderstore and installed automatically.

## Installation
Install with a mod manager (Thunderstore Mod Manager, r2modman) or manually:

```
<GameRoot>/
  BepInEx/
    plugins/
      FFAArena_Lite/
        FFAArena_Lite.dll
```

## Configuration
* Initial lives per player can be set in BepInEx config (section "FFA"). Default is tuned for last‑player‑standing.

## Compatibility
* Designed to be low‑impact and compatible with most content/visual mods.
* If another mod replaces spawn logic, load order may affect results.

## Known notes
* Late joiners may briefly show inaccurate lives until they see new deaths. Eliminations still resolve correctly.

## Support
* Feedback and issues: GitHub (see manifest) or Thunderstore comments.

Have fun!
